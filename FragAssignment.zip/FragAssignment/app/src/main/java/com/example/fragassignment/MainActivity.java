package com.example.fragassignment;

import android.os.Bundle;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements FragmentA.FragmentInteractionListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button buttonLoadFragmentA = findViewById(R.id.button_load_fragment_a);
        Button buttonLoadFragmentB = findViewById(R.id.button_load_fragment_b);

        buttonLoadFragmentA.setOnClickListener(v -> loadFragmentA());
        buttonLoadFragmentB.setOnClickListener(v -> loadFragmentB());

        // Load Fragment A by default
        if (savedInstanceState == null) {
            loadFragmentA();
        }
    }

    private void loadFragmentA() {
        FragmentA fragmentA = new FragmentA();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragmentA)
                .addToBackStack(null)
                .commit();
    }

    private void loadFragmentB() {
        FragmentB fragmentB = new FragmentB();
        Bundle bundle = new Bundle();
        bundle.putString("name", getLastEnteredName()); // This will hold the last entered name
        fragmentB.setArguments(bundle);

        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, fragmentB)
                .addToBackStack(null)
                .commit();
    }

    private String lastEnteredName;

    @Override
    public void onNameSubmitted(String name) {
        lastEnteredName = name;
        loadFragmentB();
    }

    private String getLastEnteredName() {
        return lastEnteredName != null ? lastEnteredName : "";
    }
}
